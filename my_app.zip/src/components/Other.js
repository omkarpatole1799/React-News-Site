import React from 'react'
function Other(props) {
  return (

    <>
      <p>name: {props.data.name}  email:<b> { props.data.email } </b></p>
      <p></p>

    </>
  )
}

export default Other