import React from 'react'

function ApiUpdateData1() {
    return (
        <>

            <div className="container"> </div>

        </>
    )
}

export default ApiUpdateData1